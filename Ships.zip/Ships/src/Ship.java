import java.util.List;

public class Ship {
    private int size;
    private boolean sunk;
    private List<int[]> coordinates;

    public Ship(int size) {
        this.size = size;
        this.sunk = false;
    }

    public int getSize(){
        return this.size;
    }

    public boolean isSunk(){
        return this.sunk;
    }

    public void setSunk(boolean sunk){this.sunk = true;}

    public List< int[]> getCoordinates(){return this.coordinates;}

    public void  setCoordinates(List<int[]> coordinates){this.coordinates = coordinates;}

}
