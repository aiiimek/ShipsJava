import java.util.ArrayList;
import java.util.List;
public class Player {
    private char[][] board;
    private List<Ship> ships;

    public Player(){
        board = new char [10][10];
        ships = new ArrayList<>();

        for (int i=0; i<10; i++){
            for (int j=0; j<10; j++){
                board[i][j] = '~';
            }
        }
    }
    public char[][] getBoard(){
        return board;
    }
    public List<Ship> getShips(){
        return ships;
    }
    public void addShip(Ship ship){
        ships.add(ship);
    }
    public boolean hasShipsLeft(){
        return ships != null && ships.stream().anyMatch(ship -> !ship.isSunk());
    }

    public int getHits(){
        return hits;
    }
    public void IncrementHits(){
        hits++;
    }
}
