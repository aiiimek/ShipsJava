public class Boat extends Ship{
    public Boat(){
        super(2);

    }
}
