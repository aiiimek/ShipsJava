public class BattleShip extends Ship{
    public BattleShip() {
        super(4);
    }
}
