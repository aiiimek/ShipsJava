import java.util.Random;
public class Game {
    private Player player1;
    private Player player2;
    private Player currentplayer;
}

public Game(){
    player1 = new Player();
    player2 = new Player();
    currentplayer = player1;

    placeShipsRandomly(player1);
    placeShipsRandomly(player2);
}

private void placeShipsRandomly(Player player){
    Random random = new Random();
    Ship[] ships={new Boat(),new Cruise(),new Destroyer(),new BattleShip()};

    for (Ship ship : ships){
        boolean placed = false;

        while (!placed){
            int x = random.nextInt(10);
            int y = random.nextInt(10);

            boolean horizontal= random.nextBoolean();

            if(canPlaceShip(player.getBoard(), ship.getSize(), x, y, horizontal)){
                placeShip(player.getBoard(), ship.getSize(), x, y, horizontal);
                player.addShip(ship);
                placed = true;
            }
        }
    }
}

private boolean canPlaceShip(char[][] board, int size, int x, int y, boolean horizontal){
    for (int i=0; i<size; i++){
        int nx= x+(horizontal ? 0: i );
        int ny= y+(horizontal ? i : 0 );

        if (nx >= 10 || ny >= 10 || board[nx][ny] != '~'){
            return false;
        }
    }
    return true;
}

private void placeShip(char[][] board, int size, int x, int y, boolean horizontal){
    for ( int i=0; i< ship.getSize(); i++){
        int nx = x + (horizontal ? 0 : i);
        int ny = y + (horizontal ? i : 0);
        board[nx][ny] = 'S';
    }
}
public boolean shootAtOpponent(int x, int y) {
    Player opponent = (currentPlayer == player1) ? player2 : player1;
    char[][] opponentBoard = opponent.getBoard();

    if (opponentBoard[x][y] == 'S') { //hit
        opponentBoard[x][y] = 'X'; // mark hit
        currentPlayer.incrementHits();
        checkIfShipSunk(opponent, x, y);
        return true;
    } else if (opponentBoard[x][y] == '~') { // miss
        opponentBoard[x][y] = '*'; // mark miss
    }
    return false;
}


public void switchPlayer(){
    currentplayer = (currentplayer == player1) ? player2 : player1;
}

public void isGameOver() {
    retturn !player1.hasShipsLeft || !player2.hasShipsLeft;
}

public Player getWinner(){
    return player1.hasShipsLeft ? player1 : player2;
}

