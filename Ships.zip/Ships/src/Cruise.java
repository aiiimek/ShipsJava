public class Cruise extends Ship {
    public Cruise() {
        super(3);
    }
}
