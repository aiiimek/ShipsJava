public class Destroyer  extends Ship{
    public Destroyer(){
        super(5);
    }
}
