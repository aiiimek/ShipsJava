import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        Scanner scanner = new Scanner(System.in);

        while (!game.isGameOver()) {
            Player currentPlayer = game.getCurrentPlayer();
            System.out.println("Your board:");
            printBoard(currentPlayer.getBoard());

            System.out.println("Strzelaj! Podaj współrzędne (x y):");
            int x = scanner.nextInt();
            int y = scanner.nextInt();

            boolean hit = game.shootAtOpponent(x, y);
            if (hit) {
                System.out.println("HIT!");
            } else {
                System.out.println("Miss!");
                game.switchPlayer();
            }

            System.out.println("Player 1: hits: " + game.getPlayer1().getHits());
            System.out.println("Player 2: hits: " + game.getPlayer2().getHits());
        }

        System.out.println("Game over!");
        Player winner = game.getWinner();
        System.out.println("Winner is: " + (winner == game.getPlayer1() ? "1" : "2"));
    }

    private static void printBoard(char[][] board) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }
}
